# 🤖 Bot Telegram – Antônio Borges 122
## Guia de Instalação Passo a Passo

---

## 📁 Arquivos do projeto

| Arquivo | Função |
|---|---|
| `bot.py` | Código principal do bot |
| `unidades.py` | Lê e grava a planilha Excel |
| `Unidades_AntonioBorges.xlsx` | Planilha com as 18 unidades |
| `requirements.txt` | Bibliotecas necessárias |
| `.env.exemplo` | Modelo de configuração |
| `Procfile` | Para hospedagem no Railway/Render |

---

## PASSO 1 – Criar o bot no Telegram

1. Abra o Telegram e pesquise por **@BotFather**
2. Envie `/newbot`
3. Escolha um nome: ex. `Antônio Borges Imóveis`
4. Escolha um usuário: ex. `antonio_borges_imoveis_bot`
5. O BotFather vai te enviar um **TOKEN** — copie e guarde!
   - Exemplo: `7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

---

## PASSO 2 – Descobrir seu ID de admin

1. No Telegram, pesquise **@userinfobot**
2. Envie qualquer mensagem
3. Ele responde com seu **ID numérico** — copie!

---

## PASSO 3 – Hospedar no Railway (gratuito)

### 3.1 Criar conta
- Acesse https://railway.app
- Crie conta com GitHub (gratuito)

### 3.2 Subir o projeto
1. Crie uma conta no GitHub (https://github.com) se não tiver
2. Crie um repositório chamado `antonio-borges-bot`
3. Faça upload de todos os arquivos desta pasta
4. No Railway: clique em **New Project → Deploy from GitHub Repo**
5. Selecione o repositório `antonio-borges-bot`

### 3.3 Configurar variáveis de ambiente
No Railway, vá em **Variables** e adicione:

```
TELEGRAM_TOKEN = (seu token do BotFather)
ADMIN_IDS = (seu ID numérico, ex: 123456789)
```

### 3.4 Fazer o deploy
- Clique em **Deploy**
- Aguarde ficar verde ✅

---

## PASSO 4 – Adicionar o bot ao grupo

1. No Telegram, crie (ou abra) o grupo dos corretores
2. Clique no nome do grupo → **Adicionar membros**
3. Pesquise pelo usuário do bot (ex: `@antonio_borges_imoveis_bot`)
4. Adicione e pronto!

---

## 💬 Comandos disponíveis no grupo

| Comando | O que faz |
|---|---|
| `/start` | Lista todos os comandos |
| `/disponiveis` | Mostra unidades disponíveis |
| `/todas` | Lista todas as 18 unidades com status |
| `/resumo` | Painel com totais e % vendido |
| `/reservar Apto 101 João Silva` | Marca como RESERVADO *(admin)* |
| `/vender Apto 101 João Silva` | Marca como VENDIDO *(admin)* |
| `/liberar Apto 101` | Volta para DISPONÍVEL *(admin)* |

---

## 📊 Atualizar pela planilha Excel

1. Abra o arquivo `Unidades_AntonioBorges.xlsx`
2. Altere o campo **Status** para: `DISPONÍVEL`, `RESERVADO` ou `VENDIDO`
3. Preencha o campo **Comprador** se necessário
4. Salve o arquivo
5. Faça upload da versão atualizada no GitHub (o Railway vai atualizar automaticamente)

---

## ❓ Dúvidas comuns

**O bot não responde no grupo:**
→ Verifique se o TOKEN está correto nas variáveis do Railway

**Aparece "apenas admins podem alterar":**
→ Seu ID não está na variável ADMIN_IDS — adicione-o

**Erro ao alterar unidade:**
→ Use exatamente o formato: `Apto 101`, `Apto 102`, etc.

---

## 📞 Suporte
Em caso de dúvidas técnicas, entre em contato com quem configurou o sistema.
