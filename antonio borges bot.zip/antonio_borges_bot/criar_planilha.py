import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Unidades"

# Cores
verde = PatternFill("solid", fgColor="C6EFCE")
vermelho = PatternFill("solid", fgColor="FFC7CE")
amarelo = PatternFill("solid", fgColor="FFEB9C")
azul_escuro = PatternFill("solid", fgColor="1F4E79")
cinza = PatternFill("solid", fgColor="D9D9D9")

borda = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)

# Cabeçalho principal
ws.merge_cells("A1:F1")
ws["A1"] = "ANTÔNIO BORGES 122 – CONTROLE DE UNIDADES"
ws["A1"].font = Font(bold=True, color="FFFFFF", size=13)
ws["A1"].fill = azul_escuro
ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
ws.row_dimensions[1].height = 30

# Cabeçalhos das colunas
headers = ["Unidade", "Bloco", "Tipo", "Status", "Comprador", "Observação"]
for col, h in enumerate(headers, 1):
    cell = ws.cell(row=2, column=col, value=h)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="2E75B6")
    cell.alignment = Alignment(horizontal="center")
    cell.border = borda

# 18 unidades: 2 blocos x 3 andares x 3 aptos por andar
unidades = []
for bloco in ["A", "B"]:
    for andar in range(1, 4):  # 3 andares
        for apto in range(1, 4):  # 3 aptos por andar
            num = f"{andar}0{apto}"
            unidades.append({
                "unidade": f"Apto {num}",
                "bloco": f"Bloco {bloco}",
                "tipo": "2 Qtos",
                "status": "DISPONÍVEL",
                "comprador": "",
                "obs": ""
            })

# Preencher dados
for i, u in enumerate(unidades):
    row = i + 3
    ws.cell(row=row, column=1, value=u["unidade"]).border = borda
    ws.cell(row=row, column=2, value=u["bloco"]).border = borda
    ws.cell(row=row, column=3, value=u["tipo"]).border = borda
    status_cell = ws.cell(row=row, column=4, value=u["status"])
    status_cell.border = borda
    status_cell.alignment = Alignment(horizontal="center")
    status_cell.fill = verde
    ws.cell(row=row, column=5, value=u["comprador"]).border = borda
    ws.cell(row=row, column=6, value=u["obs"]).border = borda
    for col in range(1, 7):
        ws.cell(row=row, column=col).alignment = Alignment(horizontal="center")

# Linha de legenda
leg_row = len(unidades) + 4
ws.cell(row=leg_row, column=1, value="LEGENDA:").font = Font(bold=True)
legendas = [
    ("DISPONÍVEL", verde), ("RESERVADO", amarelo), ("VENDIDO", vermelho)
]
for idx, (texto, cor) in enumerate(legendas):
    c = ws.cell(row=leg_row, column=idx+2, value=texto)
    c.fill = cor
    c.border = borda
    c.alignment = Alignment(horizontal="center")
    c.font = Font(bold=True)

# Larguras das colunas
larguras = [14, 14, 12, 14, 28, 28]
for col, w in enumerate(larguras, 1):
    ws.column_dimensions[get_column_letter(col)].width = w

wb.save("/home/claude/antonio_borges_bot/Unidades_AntonioBorges.xlsx")
print("Planilha criada!")
